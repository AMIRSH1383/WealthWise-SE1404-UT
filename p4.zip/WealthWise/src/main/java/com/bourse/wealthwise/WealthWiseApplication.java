package com.bourse.wealthwise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WealthWiseApplication {

    public static void main(String[] args) {
        SpringApplication.run(WealthWiseApplication.class, args);
    }

}
