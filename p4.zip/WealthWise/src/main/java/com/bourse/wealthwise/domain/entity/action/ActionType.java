package com.bourse.wealthwise.domain.entity.action;

public enum ActionType {
    BUY,
    SALE,
    DEPOSIT,
    WITHDRAWAL,

}
