package com.bourse.wealthwise.domain.entity.action;

public enum Actor {
    MANUAL,
    PUBLISHER
}
