package com.bourse.wealthwise.domain.entity.portfolio;

public enum PortfolioStatus {
    ACTIVE,
    INACTIVE
}
