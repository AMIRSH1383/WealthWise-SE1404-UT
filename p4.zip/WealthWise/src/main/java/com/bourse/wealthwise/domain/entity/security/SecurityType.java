package com.bourse.wealthwise.domain.entity.security;

public enum SecurityType {
    STOCK,
    STOCK_RIGHT,
    OPTION
}
